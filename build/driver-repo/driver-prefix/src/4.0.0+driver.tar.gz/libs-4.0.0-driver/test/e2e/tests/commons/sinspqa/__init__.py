import os

LOGS_PATH = '/logs'
SINSP_LOG_PATH = os.path.join(LOGS_PATH, 'sinsp.log')

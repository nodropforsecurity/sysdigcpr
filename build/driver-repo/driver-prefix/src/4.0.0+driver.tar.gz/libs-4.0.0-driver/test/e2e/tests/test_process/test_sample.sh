#! /usr/bin/env bash
echo "Some random string" > /tmp/test.txt
cat /tmp/test.txt
rm -f /tmp/test.txt

from setuptools import setup, find_packages

print(find_packages())

setup(name="sinspqa", packages=find_packages())

# Tail-called programs

All the BPF programs in this folder are tail-called by a dispatcher program in the `programs/attached/dispatchers` folder.
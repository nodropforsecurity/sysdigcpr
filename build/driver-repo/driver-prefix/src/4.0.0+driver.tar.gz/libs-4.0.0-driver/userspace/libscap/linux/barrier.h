#pragma once

#define mem_barrier() __sync_synchronize()
